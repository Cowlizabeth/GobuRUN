extends Node2D

const W := 960.0
const H := 540.0
const FLOOR := 430.0
const PLAYER_X := 165.0
const GRAVITY := 1800.0
const JUMP_SPEED := -720.0

var goblin: Array[Texture2D] = []
var coins_tex: Array[Texture2D] = []
var crate_tex: Texture2D
var forest_tex: Texture2D
var obstacles: Array[Dictionary] = []
var coins: Array[Dictionary] = []
var py := FLOOR
var vy := 0.0
var alive := true
var score := 0
var distance := 0.0
var elapsed := 0.0
var spawn_timer := 1.5
var bg_offset := 0.0
var font: Font

func _ready() -> void:
 randomize()
 for i in range(4): goblin.append(load("res://assets/goblin_%d.png" % i))
 for i in range(6): coins_tex.append(load("res://assets/coin_%d.png" % i))
 crate_tex = load("res://assets/crate.png")
 forest_tex = load("res://assets/forest.png")
 font = ThemeDB.fallback_font
 reset()

func reset() -> void:
 obstacles.clear()
 coins.clear()
 py = FLOOR
 vy = 0.0
 alive = true
 score = 0
 distance = 0.0
 elapsed = 0.0
 spawn_timer = 1.35
 bg_offset = 0.0
 queue_redraw()

func _input(event: InputEvent) -> void:
 if event is InputEventScreenTouch and event.pressed:
  jump_or_restart()
 elif event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
  jump_or_restart()
 elif event is InputEventKey and event.pressed and not event.echo and (event.keycode == KEY_SPACE or event.keycode == KEY_UP):
  jump_or_restart()

func jump_or_restart() -> void:
 if not alive:
  reset()
 elif py >= FLOOR - 1.0:
  vy = JUMP_SPEED

func _process(delta: float) -> void:
 delta = minf(delta, 0.05)
 if alive:
  elapsed += delta
  var speed := minf(520.0, 300.0 + elapsed * 6.0)
  distance += speed * delta
  bg_offset = fmod(bg_offset + speed * delta * 0.12, W)
  vy += GRAVITY * delta
  py = minf(FLOOR, py + vy * delta)
  if py >= FLOOR: vy = 0.0
  spawn_timer -= delta
  if spawn_timer <= 0.0:
   obstacles.append({"x": W + 55.0, "size": 56.0})
   # Coins are placed in reachable arcs above or between crates.
   var count := randi_range(2, 4)
   for i in range(count):
    coins.append({"x": W + 30.0 + float(i) * 42.0, "y": FLOOR - 115.0 - sin(float(i) / float(maxi(1, count-1)) * PI) * 35.0})
   spawn_timer = randf_range(1.45, 2.05) * (300.0 / speed)
  for obj in obstacles:
   obj["x"] -= speed * delta
  for coin in coins:
   coin["x"] -= speed * delta
  obstacles = obstacles.filter(func(o): return o["x"] > -100.0)
  coins = coins.filter(func(c): return c["x"] > -50.0)
  var player_rect := Rect2(PLAYER_X - 20.0, py - 57.0, 40.0, 53.0)
  for obj in obstacles:
   var crate_rect := Rect2(float(obj["x"]) - 25.0, FLOOR - 52.0, 50.0, 52.0)
   if player_rect.intersects(crate_rect):
    alive = false
    break
  for coin in coins:
   if not coin.get("taken", false) and player_rect.intersects(Rect2(float(coin["x"]) - 16.0, float(coin["y"]) - 18.0, 32.0, 36.0)):
    coin["taken"] = true
    score += 1
 queue_redraw()

func _draw() -> void:
 draw_rect(Rect2(0, 0, W, H), Color("88c8ee"))
 # Two copies give the background an endless parallax scroll.
 for i in range(2):
  draw_texture_rect(forest_tex, Rect2(float(i) * W - bg_offset, 0, W, FLOOR + 80.0), false)
 draw_rect(Rect2(0, FLOOR, W, H - FLOOR), Color("5e422e"))
 draw_rect(Rect2(0, FLOOR, W, 15), Color("7ab947"))
 draw_line(Vector2(0, FLOOR + 15), Vector2(W, FLOOR + 15), Color("426d2e"), 4.0)
 for obj in obstacles:
  draw_texture_rect(crate_tex, Rect2(float(obj["x"]) - 28.0, FLOOR - 56.0, 56, 56), false)
 var coin_frame := int(elapsed * 11.0) % coins_tex.size()
 for coin in coins:
  if not coin.get("taken", false):
   draw_texture_rect(coins_tex[coin_frame], Rect2(float(coin["x"]) - 18.0, float(coin["y"]) - 20.0, 36.0, 40.0), false)
 var running_frame := int(elapsed * 11.0) % goblin.size()
 var player_frame := running_frame if py >= FLOOR - 1.0 else 2
 draw_texture_rect(goblin[player_frame], Rect2(PLAYER_X - 34.0, py - 74.0, 68.0, 74.0), false)
 draw_string(font, Vector2(25, 47), "COINS: %d" % score, HORIZONTAL_ALIGNMENT_LEFT, -1, 28, Color("fff3a1"))
 draw_string(font, Vector2(25, 81), "DISTANCE: %d" % int(distance / 10.0), HORIZONTAL_ALIGNMENT_LEFT, -1, 21, Color.WHITE)
 if not alive:
  draw_rect(Rect2(0, 0, W, H), Color(0.05, 0.06, 0.07, 0.68))
  draw_string(font, Vector2(0, 225), "GAME OVER", HORIZONTAL_ALIGNMENT_CENTER, int(W), 64, Color("ffdc85"))
  draw_string(font, Vector2(0, 282), "Coins: %d    Distance: %d" % [score, int(distance / 10.0)], HORIZONTAL_ALIGNMENT_CENTER, int(W), 27, Color.WHITE)
  draw_string(font, Vector2(0, 337), "TAP TO RESTART", HORIZONTAL_ALIGNMENT_CENTER, int(W), 30, Color.WHITE)
 elif elapsed < 3.0:
  draw_string(font, Vector2(0, 140), "TAP TO JUMP", HORIZONTAL_ALIGNMENT_CENTER, int(W), 28, Color.WHITE)

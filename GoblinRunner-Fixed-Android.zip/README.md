# Goblin Runner 🟢

Простой бесконечный 2D-раннер для Android на **Godot 4**.

## Как играть
- Гоблин бежит сам.
- Нажми на экран, пробел или стрелку вверх, чтобы прыгнуть.
- Собирай монеты и перепрыгивай ящики.
- Столкновение с ящиком завершает забег. Нажми снова, чтобы начать заново.

## Как открыть
1. Установи Godot 4 с https://godotengine.org/download/.
2. Нажми **Import** и укажи `project.godot` из этой папки.
3. Нажми **F6/F5** (запуск проекта — F5).
4. Для Android: `Project → Export → Add → Android`; установи экспортные шаблоны и настрой Android SDK согласно https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_android.html. Экспортируй APK.

## Как загрузить на GitHub
Создай пустой репозиторий, затем загрузи в него **все файлы из папки GoblinRunner**. Не включай папку `.godot`.

## Устройство проекта
- `game.gd` — игровая логика, анимация, касания, препятствия, счёт.
- `main.tscn` — игровая сцена.
- `assets/goblin_*.png` — 4 кадра бега.
- `assets/coin_*.png` — 6 кадров вращения монеты.
- `assets/crate.png` — ящик.
- `assets/forest.png` — лесной фон.

Анимация реализована встроенными средствами Godot переключением кадров — внешняя библиотека не нужна. Если речь шла о **Spine**, **Spriter** или другом open-source инструменте, анимацию можно заменить позднее.

## Автоматическая сборка APK через GitHub Actions (только с телефона)
1. Создай пустой репозиторий `GoblinRunner` на GitHub, основная ветка `main`.
2. Загрузи **содержимое** этой папки в корень репозитория (не саму внешнюю папку). Убедись, что в корне есть `project.godot` и `export_presets.cfg`, а в `.github/workflows/` — `android-apk.yml`.
3. GitHub → Actions → Build Android APK → Run workflow. Сборка также запускается после push в `main`.
4. Открой завершённый запуск, пролистай до **Artifacts**, скачай `GoblinRunner-Android`, распакуй ZIP и установи `GoblinRunner-debug.apk`.

Это **debug APK для тестирования**, а не релиз с личным ключом подписи для Play Store.
